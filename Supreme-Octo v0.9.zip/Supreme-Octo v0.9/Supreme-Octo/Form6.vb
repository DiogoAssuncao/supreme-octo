﻿Public Class Form6
    Dim v As Integer = 0
    Dim m As Integer = 0
    Dim lc As Integer = 0
    ''lc = 1 ultimo char = numero
    ''lc = 2 ulrimo char = operacao
    Dim Txt, aaa As String
    Private Sub Checker()
        Dim c As Integer
        Dim TxtArr() As String
        Txt = TextBox1.Text
        TxtArr = Txt.Split(" ")
        aaa = 0
        c = Txt.Length
        If String.IsNullOrEmpty(Txt) Then
            lc = 0
        End If
        If c > 2 Then
            If (TxtArr(TxtArr.Length - 1) = "+" Or TxtArr(TxtArr.Length - 1) = "-" Or TxtArr(TxtArr.Length - 1) = "*" Or TxtArr(TxtArr.Length - 1) = "/") Then
                aaa = 1
            End If
        End If
    End Sub
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = TextBox1.Text + "1"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        TextBox1.Text = TextBox1.Text + "2"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        TextBox1.Text = TextBox1.Text + "3"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        TextBox1.Text = TextBox1.Text + "4"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        TextBox1.Text = TextBox1.Text + "5"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        TextBox1.Text = TextBox1.Text + "6"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        TextBox1.Text = TextBox1.Text + "7"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        TextBox1.Text = TextBox1.Text + "8"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        TextBox1.Text = TextBox1.Text + "9"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub Button0_Click(sender As System.Object, e As System.EventArgs) Handles Button0.Click
        TextBox1.Text = TextBox1.Text + "0"
        lc = 1
        ButtonEnter.Select()
    End Sub

    Private Sub ButtonMenos_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMenos.Click
        Checker()
        If aaa = 0 And lc = 1 Then
            TextBox1.Text = TextBox1.Text + " - "
            lc = 2
            v = 0
            m = 0
        ElseIf (lc = 2 Or lc = 0) And m = 0 Then
            TextBox1.Text = TextBox1.Text + "-"
            m = 1
        End If
        ButtonEnter.Select()
    End Sub

    Private Sub ButtonMais_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMais.Click
        Checker()
        If aaa = 0 And lc = 1 Then
            TextBox1.Text = TextBox1.Text + " + "
            lc = 2
            v = 0
            m = 0
        End If
        ButtonEnter.Select()
    End Sub

    Private Sub ButtonEnter_Click(sender As System.Object, e As System.EventArgs) Handles ButtonEnter.Click
        TextBox2.Text = TextBox2.Text + vbCrLf + TextBox1.Text
        Dim Resultado As Double
        Dim n, l, n1 As Integer
        n = 1
        n1 = 1
        Dim TextArr() As String
        Txt = TextBox1.Text
        TextArr = Txt.Split(" ")
        l = TextArr.Length
        While n1 <= l - 1
            Txt = TextBox1.Text
            TextArr = Txt.Split(" ")
            l = TextArr.Length
            If TextArr(n1) = "*" Or TextArr(n1) = "/" Then
                If TextArr(n1) = "*" Then
                    Dim n2 As Integer
                    Dim s1 As Double
                    n2 = 1
                    TextBox1.Clear()
                    If n1 <> 1 Then
                        TextBox1.Text = TextArr(0)
                    End If
                    While (n2 < n1 - 1)
                        If n2 = n1 - 2 Then
                            TextBox1.Text = TextBox1.Text + " " + TextArr(n2) + " "
                        Else
                            TextBox1.Text = TextBox1.Text + " " + TextArr(n2)
                        End If
                        n2 += 1
                    End While
                    s1 = Convert.ToDouble(TextArr(n1 - 1)) * Convert.ToDouble(TextArr(n1 + 1))
                    TextBox1.Text = TextBox1.Text + Convert.ToString(s1)
                    n2 = n1 + 2
                    While n2 < l
                        TextBox1.Text = TextBox1.Text + " " + TextArr(n2)
                        n2 += 1
                    End While
                    TextBox2.Text = TextBox2.Text & vbCrLf & TextBox1.Text
                End If
                If TextArr(n1) = "/" Then
                    Dim n2 As Integer
                    Dim s1 As Double
                    n2 = 1
                    TextBox1.Clear()
                    If n1 <> 1 Then
                        TextBox1.Text = TextArr(0)
                    End If
                    While (n2 < n1 - 1)
                        If n2 = n1 - 2 Then
                            TextBox1.Text = TextBox1.Text + " " + TextArr(n2) + " "
                        Else
                            TextBox1.Text = TextBox1.Text + " " + TextArr(n2)
                        End If
                        n2 += 1
                    End While
                    s1 = Convert.ToDouble(TextArr(n1 - 1)) / Convert.ToDouble(TextArr(n1 + 1))
                    TextBox1.Text = TextBox1.Text + Convert.ToString(s1)
                    n2 = n1 + 2
                    While n2 < l
                        TextBox1.Text = TextBox1.Text + " " + TextArr(n2)
                        n2 += 1
                    End While
                    TextBox2.Text = TextBox2.Text & vbCrLf & TextBox1.Text
                End If
                n1 = -1
            End If
            n1 += 2
            Txt = TextBox1.Text
            TextArr = Txt.Split(" ")
            l = TextArr.Length
        End While
        Txt = TextBox1.Text
        TextArr = Txt.Split(" ")
        l = TextArr.Length
        While TextArr.Length > 1
            Txt = TextBox1.Text
            TextArr = Txt.Split(" ")
            l = TextArr.Length
            If TextArr(1) = "+" Then
                Resultado = Convert.ToDouble(TextArr(0)) + Convert.ToDouble(TextArr(2))
                TextBox1.Clear()
                TextBox1.Text = Convert.ToString(Resultado)
                n = 3
                While n < TextArr.Length
                    TextBox1.Text = TextBox1.Text + " " + TextArr(n)
                    n += 1
                End While
                TextBox2.Text = TextBox2.Text & vbCrLf & TextBox1.Text
            End If
            If TextArr(1) = "-" Then
                Resultado = Convert.ToDouble(TextArr(0)) - Convert.ToDouble(TextArr(2))
                TextBox1.Clear()
                TextBox1.Text = Convert.ToString(Resultado)
                n = 3
                While n < TextArr.Length
                    TextBox1.Text = TextBox1.Text + " " + TextArr(n)
                    n += 1
                End While
                TextBox2.Text = TextBox2.Text & vbCrLf & TextBox1.Text
            End If
            Txt = TextBox1.Text
            TextArr = Txt.Split(" ")
            l = TextArr.Length
        End While
    End Sub

    Private Sub ButtonDiv_Click(sender As System.Object, e As System.EventArgs) Handles ButtonDiv.Click
        Checker()
        If aaa = 0 And lc = 1 Then
            TextBox1.Text = TextBox1.Text + " / "
            lc = 2
            v = 0
            m = 0
        End If
        ButtonEnter.Select()
    End Sub

    Private Sub ButtonMult_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMult.Click
        Checker()
        If aaa = 0 And lc = 1 Then
            TextBox1.Text = TextBox1.Text + " * "
            lc = 2
            v = 0
            m = 0
        End If
        ButtonEnter.Select()
    End Sub

    Private Sub ButtonClear_Click(sender As System.Object, e As System.EventArgs) Handles ButtonClear.Click
        TextBox1.Clear()
        lc = 0
        ButtonEnter.Select()
        m = 0
    End Sub

    Private Sub ButtonDelete_Click(sender As System.Object, e As System.EventArgs) Handles ButtonDelete.Click
        Dim y As Integer = 0
        Dim n As Integer = 1
        Dim n1 As Integer = 1
        Dim TxtArr() As String
        Dim OrTxt As String = TextBox1.Text
        If String.IsNullOrEmpty(OrTxt) Then
            lc = 0
        Else
            OrTxt = TextBox1.Text
            TxtArr = OrTxt.Split(" ")
            If lc = 1 Then
                n = 1
                n1 = 1
                If TxtArr(TxtArr.Length - 1).Length = 1 Then
                    TextBox1.Clear()
                    If TxtArr.Length - 1 <> 0 Then
                        TextBox1.Text = TxtArr(0)
                    End If
                    While n < TxtArr.Length - 1
                        If n = TxtArr.Length - 2 Then
                            TextBox1.Text = TextBox1.Text + " " + TxtArr(n) + " "
                        Else
                            TextBox1.Text = TextBox1.Text + " " + TxtArr(n)
                        End If
                        n += 1
                    End While
                    lc = 2
                    y = 1
                Else
                    TextBox1.Clear()
                    If TxtArr.Length - 1 <> 0 Then
                        TextBox1.Text = TxtArr(0)
                    End If
                    While n < TxtArr.Length - 1
                        If n = TxtArr.Length - 2 Then
                            TextBox1.Text = TextBox1.Text + " " + TxtArr(n) + " "
                        Else
                            TextBox1.Text = TextBox1.Text + " " + TxtArr(n)
                        End If
                        n += 1
                    End While
                    Dim lnt As String
                    lnt = TxtArr(TxtArr.Length - 1)(0)
                    While n1 < TxtArr(TxtArr.Length - 1).Length - 1
                        lnt = lnt + TxtArr(TxtArr.Length - 1)(n1)
                        n1 += 1
                    End While
                    TextBox1.Text = TextBox1.Text + lnt
                End If
            End If
            If lc = 2 And y <> 1 Then
                OrTxt = TextBox1.Text
                TxtArr = OrTxt.Split(" ")
                n = 1
                n1 = 1
                TextBox1.Clear()
                TextBox1.Text = TxtArr(0)
                While n1 < TxtArr.Length - 3
                    TextBox1.Text = TextBox1.Text + " " + TxtArr(n1)
                    n1 += 1
                End While
                OrTxt = TextBox1.Text
                TxtArr = OrTxt.Split(" ")
                lc = 1

            End If
        End If
        y = 0
    End Sub

    Private Sub ButtonDot_Click(sender As System.Object, e As System.EventArgs) Handles ButtonDot.Click
        Checker()
        If aaa = 0 And lc = 1 And v = 0 Then
            TextBox1.Text = TextBox1.Text + ","
            lc = 2
            v = 1
        End If
        ButtonEnter.Select()
    End Sub

    Private Sub TextBox1_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b0_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button0.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b1_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button1.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b2_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button2.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b3_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button3.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b4_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button4.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b5_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button5.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b6_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button6.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b7_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button7.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b8_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button8.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub b9_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles Button9.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub bma_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonMais.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub bme_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonMenos.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub bmu_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonMult.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub bdi_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonDiv.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub be_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonEnter.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub bde_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonDelete.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub bdo_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonDot.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub
    Private Sub bc_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles ButtonClear.KeyDown
        If e.KeyCode = Keys.D0 Or e.KeyCode = Keys.NumPad0 Then
            Button0.PerformClick()
        End If
        If e.KeyCode = Keys.D1 Or e.KeyCode = Keys.NumPad1 Then
            Button1.PerformClick()
        End If
        If e.KeyCode = Keys.D2 Or e.KeyCode = Keys.NumPad2 Then
            Button2.PerformClick()
        End If
        If e.KeyCode = Keys.D3 Or e.KeyCode = Keys.NumPad3 Then
            Button3.PerformClick()
        End If
        If e.KeyCode = Keys.D4 Or e.KeyCode = Keys.NumPad4 Then
            Button4.PerformClick()
        End If
        If e.KeyCode = Keys.D5 Or e.KeyCode = Keys.NumPad5 Then
            Button5.PerformClick()
        End If
        If e.KeyCode = Keys.D6 Or e.KeyCode = Keys.NumPad6 Then
            Button6.PerformClick()
        End If
        If e.KeyCode = Keys.D7 Or e.KeyCode = Keys.NumPad7 Then
            Button7.PerformClick()
        End If
        If e.KeyCode = Keys.D8 Or e.KeyCode = Keys.NumPad8 Then
            Button8.PerformClick()
        End If
        If e.KeyCode = Keys.D9 Or e.KeyCode = Keys.NumPad9 Then
            Button9.PerformClick()
        End If
        If e.KeyCode = Keys.Enter Then
            ButtonEnter.PerformClick()
        End If
        If e.KeyCode = Keys.Back Then
            ButtonDelete.PerformClick()
        End If
        If e.KeyCode = Keys.Decimal Then
            ButtonDot.PerformClick()
        End If
        If e.KeyCode = Keys.Subtract Then
            ButtonMenos.PerformClick()
        End If
        If e.KeyCode = Keys.Add Then
            ButtonMais.PerformClick()
        End If
        If e.KeyCode = Keys.Divide Then
            ButtonDiv.PerformClick()
        End If
        If e.KeyCode = Keys.Multiply Then
            ButtonMult.PerformClick()
        End If
    End Sub

    Private Sub ButtonClr_Click(sender As System.Object, e As System.EventArgs) Handles ButtonClr.Click
        TextBox3.Clear()
    End Sub

    ''LOG CALC
    Dim Tb3, tb3Arr() As String
    Dim l As Integer = 0
    Dim pp As Integer = 0
    '' 1 -> V\F   2 -> &&\||   3 2\1 -> )\( 
    Private Sub Checker2()
        Dim d As Integer
        Tb3 = TextBox3.Text
        tb3Arr = Tb3.Split(" ")
        If String.IsNullOrEmpty(Tb3) Then
            l = 0
        End If
        d = tb3Arr.Length
        If tb3Arr(d - 1) = "&&" Or tb3Arr(d - 1) = "||" Then
            l = 2
        End If
        If tb3Arr(d - 1) = "V" Or tb3Arr(d - 1) = "F" Then
            l = 1
        End If
        If tb3Arr(d - 1) = "(" Then
            l = 31
        End If
        If tb3Arr(d - 1) = ")" Then
            l = 32
        End If
        Dim cnt1 As Integer = 0
        Dim cnt2 As Integer = 0
        For Each c In Tb3
            If c = "(" Then
                cnt1 += 1
            End If
            If c = ")" Then
                cnt2 += 1
            End If
        Next
        pp = 0
        If cnt1 = cnt2 Then
            pp = 1
        End If
    End Sub

    Private Sub ButtonV_Click(sender As System.Object, e As System.EventArgs) Handles ButtonV.Click
        Checker2()
        If l <> 1 And l <> 32 Then
            If l = 0 Then
                TextBox3.Text = TextBox3.Text + " V"
                l = 1
            Else
                TextBox3.Text = TextBox3.Text + "V"
                l = 1
            End If
        End If
    End Sub

    Private Sub ButtonF_Click(sender As System.Object, e As System.EventArgs) Handles ButtonF.Click
        Checker2()
        If l <> 1 And l <> 32 Then
            If l = 0 Then
                TextBox3.Text = TextBox3.Text + " F"
                l = 1
            Else
                TextBox3.Text = TextBox3.Text + "F"
                l = 1
            End If
        End If
    End Sub

    Private Sub ButtonMa_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMa.Click
        Checker2()
        If (l = 1 Or l = 32) And l <> 0 Then
            TextBox3.Text = TextBox3.Text + " && "
            l = 2
        End If
    End Sub

    Private Sub ButtonMe_Click(sender As System.Object, e As System.EventArgs) Handles ButtonMe.Click
        Checker2()
        If (l = 1 Or l = 32) And l <> 0 Then
            TextBox3.Text = TextBox3.Text + " || "
            l = 2
        End If
    End Sub

    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        Checker2()
        If l <> 32 And l <> 1 Then
            If l = 2 Then
                TextBox3.Text = TextBox3.Text + "( "
                l = 31
            Else
                TextBox3.Text = TextBox3.Text + " ( "
                l = 31
            End If
        End If
    End Sub

    Private Sub Button11_Click(sender As System.Object, e As System.EventArgs) Handles Button11.Click
        Checker2()
        If l <> 31 And l <> 0 And l <> 2 And pp = 0 Then
            TextBox3.Text = TextBox3.Text + " )"
            l = 32
        End If
    End Sub

    Private Sub ButtonEnt_Click(sender As System.Object, e As System.EventArgs) Handles ButtonEnt.Click
        Tb3 = TextBox3.Text
        tb3Arr = Tb3.Split(" ")
        Dim cnt1 As Integer = 0
        Dim cnt2 As Integer = 0
        For Each c In Tb3
            If c = "(" Then
                cnt1 += 1
            End If
            If c = ")" Then
                cnt2 += 1
            End If
        Next
        If cnt1 = cnt2 And l <> 2 Then
            TextBox2.Text = TextBox2.Text + vbCrLf + TextBox3.Text
            If cnt1 <> 0 Then
                Dim Pa(cnt1), Pf(cnt2), n, pac, pfc As Integer
                n = 0
                pac = 0
                pfc = 0
                While n < tb3Arr.Length
                    If tb3Arr(n) = "(" Then
                        Pa(pac) = n
                        pac += 1
                    End If
                    If tb3Arr(n) = ")" Then
                        Pf(pfc) = n
                        pfc += 1
                    End If
                    n += 1
                End While
                n = 1
                While n <= cnt1
                    Dim a, b, tempa, tempb, temps, tempso As Integer
                    a = 0
                    tempa = 0
                    b = 0
                    tempb = 0
                    temps = 0
                    tempso = 0
                    While a < pac
                        b = 0
                        While b < pfc
                            If ((Pf(b) - Pa(a)) < temps And (Pf(b) - Pa(a)) > 0) Or temps = 0 Then
                                temps = Pf(b) - Pa(a)
                                tempa = Pa(a)
                                tempb = Pf(b)
                            End If
                            If (Pf(b) + Pa(a) > tempso And (Pf(b) - Pa(a)) > 0) Or tempso = 0 Then
                                tempso = Pf(b) + Pa(a)
                            End If
                            b += 1
                        End While
                        a += 1
                    End While
                    TextBox3.Clear()
                    Dim p As Integer = 1
                    TextBox3.Text = tb3Arr(0)
                    While p < tempa - 1
                        TextBox3.Text = TextBox3.Text + " " + tb3Arr(p)
                        p += 1
                    End While
                    If tempa = 1 Then
                        TextBox3.Text = TextBox3.Text + " "
                    Else
                        TextBox3.Text = TextBox3.Text + " " + tb3Arr(tempa - 1) + " "
                    End If
                    Dim j As String
                    j = Solve2(tb3Arr, tempa, tempb)
                    TextBox3.Text = TextBox3.Text + j
                    p = tempb + 1
                    While p < tb3Arr.Length
                        TextBox3.Text = TextBox3.Text + " " + tb3Arr(p)
                        p += 1
                    End While
                    Tb3 = TextBox3.Text
                    tb3Arr = Tb3.Split(" ")
                    Dim o As Integer
                    o = 0
                    pac = 0
                    pfc = 0
                    While o < tb3Arr.Length
                        If tb3Arr(o) = "(" Then
                            Pa(pac) = o
                            pac += 1
                        End If
                        If tb3Arr(o) = ")" Then
                            Pf(pfc) = o
                            pfc += 1
                        End If
                        o += 1
                    End While
                    cnt1 = 0
                    For Each c In Tb3
                        If c = "(" Then
                            cnt1 += 1
                        End If
                    Next
                    n = 1
                    TextBox2.Text = TextBox2.Text + vbCrLf + TextBox3.Text
                End While
            End If
            Tb3 = TextBox3.Text
            tb3Arr = Tb3.Split(" ")
            Dim k As Integer = 2
            While k < tb3Arr.Length
                If tb3Arr(2) = "&&" Then
                    If tb3Arr(1) = "V" And tb3Arr(3) = "V" Then
                        TextBox3.Text = " V"
                    Else
                        TextBox3.Text = " F"
                    End If
                End If
                If tb3Arr(2) = "||" Then
                    If tb3Arr(1) = "V" Or tb3Arr(3) = "V" Then
                        TextBox3.Text = " V"
                    Else
                        TextBox3.Text = " F"
                    End If
                End If
                Dim kk As Integer = 4
                While kk < tb3Arr.Length
                    TextBox3.Text = TextBox3.Text + " " + tb3Arr(kk)
                    kk += 1
                End While
                Tb3 = TextBox3.Text
                tb3Arr = Tb3.Split(" ")
                TextBox2.Text = TextBox2.Text + vbCrLf + TextBox3.Text
            End While
        Else
            MsgBox("Erro")
        End If
    End Sub

    Public Function Solve(ByVal FullArray() As String, ByVal a As Integer, ByVal b As Integer)
        Dim PArray, DArray As String
        PArray = FullArray(a + 1)
        Dim k As Integer = a + 2
        While k < b
            PArray = PArray + " " + FullArray(k)
            k += 1
        End While
        DArray = PArray
        While PArray.Length > 2
            If PArray(2) = "&" Then
                If PArray(0) = "V" And PArray(5) = "V" Then
                    DArray = "V"
                Else
                    DArray = "F"
                End If
            End If
            If PArray(2) = "|" Then
                If PArray(0) = "V" Or PArray(5) = "V" Then
                    DArray = "V"
                Else
                    DArray = "F "
                End If
            End If
            k = 6
            While k < PArray.Length
                DArray = DArray + PArray(k)
                k += 1
            End While
            PArray = DArray
        End While
        Return DArray
    End Function
    Public Function Solve2(ByVal FullArray() As String, ByVal a As Integer, ByVal b As Integer)
        Dim DArray(b - a - 1) As String
        Dim k As Integer = a + 1
        Dim kk As Integer = 0
        While k < b
            DArray(kk) = FullArray(k)
            k += 1
            kk += 1
        End While
        kk = 0
        While kk < DArray.Length - 2
            If DArray(1) = "&&" Then
                If DArray(0) = "V" And DArray(2) = "V" Then
                    DArray(0) = "V"
                Else
                    DArray(0) = "F"
                End If
            End If
            If DArray(1) = "||" Then
                If DArray(0) = "V" Or DArray(2) = "V" Then
                    DArray(0) = "V"
                Else
                    DArray(0) = "F "
                End If
            End If
            k = 1
            kk = 3
            While kk < DArray.Length
                DArray(k) = DArray(kk)
                k += 1
                kk += 1
            End While
            While k < DArray.Length
                DArray(k) = 0
                k += 1
            End While
            k = 0
            kk = 0
            While k < DArray.Length
                If DArray(k) = "0" Then
                    kk += 1
                End If
                k += 1
            End While
        End While
        Return DArray(0)
    End Function
    Private Sub PictureBox4_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox4.Click
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub PictureBox3_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox3.Click
        Close()
    End Sub
End Class
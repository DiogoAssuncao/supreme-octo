﻿Public Class HangMan
    Dim count As Integer
    Dim word As String
    Dim er As Integer
    Dim tb1, tb2, tb3, tb4, tb5, tb6, tb7, tb8, tb9, tb10, tb11, tb12 As Integer
    Public Function CountCharacter(ByVal value As String) As Integer
        Dim cnt As Integer = 0
        cnt = 0
        For Each c As Char In value
            cnt += 1
        Next
        Return cnt
    End Function
    Public Sub StartGame()
        Dim n As Integer
        n = 1
        er = 0
        While n <= count
            If n = 1 Then
                TextBox2.Visible = True
            End If
            If n = 2 Then
                TextBox3.Visible = True
            End If
            If n = 3 Then
                TextBox4.Visible = True
            End If
            If n = 4 Then
                TextBox5.Visible = True
            End If
            If n = 5 Then
                TextBox6.Visible = True
            End If
            If n = 6 Then
                TextBox7.Visible = True
            End If
            If n = 7 Then
                TextBox8.Visible = True
            End If
            If n = 8 Then
                TextBox9.Visible = True
            End If
            If n = 9 Then
                TextBox10.Visible = True
            End If
            If n = 10 Then
                TextBox11.Visible = True
            End If
            If n = 11 Then
                TextBox12.Visible = True
            End If
            If n = 12 Then
                TextBox13.Visible = True
            End If
            n += 1
        End While
        TextBox14.Visible = True
        TextBox15.Visible = True
        Button3.Visible = True
        Button4.Visible = True
        TextBox1.Visible = False
        Button2.Visible = False
        tb1 = 0
        tb2 = 0
        tb3 = 0
        tb4 = 0
        tb5 = 0
        tb6 = 0
        tb7 = 0
        tb8 = 0
        tb9 = 0
        tb10 = 0
        tb11 = 0
        tb12 = 0

    End Sub

    Public Sub Button2_Click(sender As System.Object, e As System.EventArgs)
        word = TextBox1.Text
        count = CountCharacter(word)
        If count > 12 Then
            MsgBox("Max : 12 letras")
        Else
            StartGame()
        End If
        TextBox1.Clear()
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs)
        Dim sn(count) As Integer
        Dim Ver As String
        Dim Letter As String
        Dim n, x, s, y, z As Integer
        n = 0
        x = 0
        s = 0
        y = 0
        Letter = TextBox15.Text
        Ver = CountCharacter(Letter)
        If Ver > 1 Then
            MsgBox("Erro")
            TextBox15.Clear()
        Else
            While n < count
                If Letter = word(n) Then
                    x = 1
                    sn(s) = n
                    s += 1
                End If
                n += 1
            End While
            If x <> 1 Then
                erro()
            Else
                While y < s
                    z = sn(y)
                    If z = 0 Then
                        TextBox2.Text = word(z)
                        tb1 = 1
                    End If
                    If z = 1 Then
                        TextBox3.Text = word(z)
                        tb2 = 1
                    End If
                    If z = 2 Then
                        TextBox4.Text = word(z)
                        tb3 = 1
                    End If
                    If z = 3 Then
                        TextBox5.Text = word(z)
                        tb4 = 1
                    End If
                    If z = 4 Then
                        TextBox6.Text = word(z)
                        tb5 = 1
                    End If
                    If z = 5 Then
                        TextBox7.Text = word(z)
                        tb6 = 1
                    End If
                    If z = 6 Then
                        TextBox8.Text = word(z)
                        tb7 = 1
                    End If
                    If z = 7 Then
                        TextBox9.Text = word(z)
                        tb8 = 1
                    End If
                    If z = 8 Then
                        TextBox10.Text = word(z)
                        tb9 = 1
                    End If
                    If z = 9 Then
                        TextBox11.Text = word(z)
                        tb10 = 1
                    End If
                    If z = 10 Then
                        TextBox12.Text = word(z)
                        tb11 = 1
                    End If
                    If z = 11 Then
                        TextBox13.Text = word(z)
                        tb12 = 1
                    End If
                    y += 1
                End While
            End If
        End If
        TextBox15.Clear()
        Check()
    End Sub


    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs)
        Dim Guess As String
        Guess = TextBox14.Text
        If Guess = word Then
            MsgBox("You Win")
            If Quiz.HMC = 1 Then
                Me.Hide()
                Quiz.Show()
                Quiz.Score = Quiz.Score + (10 - er)
                Quiz.HMC = 2
                Quiz.CheckHM()
                PictureBox14.Visible = True
            End If
            reset()
        Else
            MsgBox("You lose")
            If Quiz.HMC = 1 Then
                Me.Hide()
                Quiz.Show()
                Quiz.HMC = 2
                Quiz.CheckHM()
                PictureBox14.Visible = True
            End If
            reset()
        End If
    End Sub
    Public Sub reset()
        TextBox14.Clear()
        TextBox1.Visible = True
        Button2.Visible = True
        TextBox14.Visible = False
        TextBox15.Visible = False
        Button3.Visible = False
        Button4.Visible = False
        TextBox2.Visible = False
        TextBox2.Clear()
        TextBox3.Visible = False
        TextBox3.Clear()
        TextBox4.Visible = False
        TextBox4.Clear()
        TextBox5.Visible = False
        TextBox5.Clear()
        TextBox6.Visible = False
        TextBox6.Clear()
        TextBox7.Visible = False
        TextBox7.Clear()
        TextBox8.Visible = False
        TextBox8.Clear()
        TextBox9.Visible = False
        TextBox9.Clear()
        TextBox10.Visible = False
        TextBox10.Clear()
        TextBox11.Visible = False
        TextBox11.Clear()
        TextBox12.Visible = False
        TextBox12.Clear()
        TextBox13.Visible = False
        TextBox13.Clear()
        PictureBox2.Visible = False
        PictureBox3.Visible = False
        PictureBox4.Visible = False
        PictureBox5.Visible = False
        PictureBox6.Visible = False
        PictureBox7.Visible = False
        PictureBox8.Visible = False
        PictureBox9.Visible = False
        PictureBox10.Visible = False
        PictureBox11.Visible = False
        PictureBox1.Visible = True
    End Sub
    Public Sub erro()
        er += 1
        If er = 1 Then
            PictureBox1.Visible = False
            PictureBox2.Visible = True
        End If
        If er = 2 Then
            PictureBox2.Visible = False
            PictureBox3.Visible = True
        End If
        If er = 3 Then
            PictureBox4.Visible = True
            PictureBox3.Visible = False
        End If
        If er = 4 Then
            PictureBox4.Visible = False
            PictureBox5.Visible = True
        End If
        If er = 5 Then
            PictureBox5.Visible = False
            PictureBox6.Visible = True
        End If
        If er = 6 Then
            PictureBox6.Visible = False
            PictureBox7.Visible = True
        End If
        If er = 7 Then
            PictureBox7.Visible = False
            PictureBox8.Visible = True
        End If
        If er = 8 Then
            PictureBox8.Visible = False
            PictureBox9.Visible = True
        End If
        If er = 9 Then
            PictureBox9.Visible = False
            PictureBox10.Visible = True
        End If
        If er = 10 Then
            PictureBox10.Visible = False
            PictureBox11.Visible = True
            MsgBox("You Lose")
            If Quiz.HMC = 1 Then
                Me.Hide()
                Quiz.Show()
                Quiz.HMC = 2
                Quiz.CheckHM()
                PictureBox14.Visible = True

            End If
            reset()
        End If
    End Sub
    Public Sub Check()
        If Quiz.HMC = 1 Then
            PictureBox12.Visible = False
            PictureBox14.Visible = False
            PictureBox15.Visible = True
        End If
        Dim soma As Integer
        soma = tb1 + tb2 + tb3 + tb4 + tb5 + tb6 + tb7 + tb8 + tb9 + tb10 + tb11 + tb12
        If count = soma Then
            MsgBox("You Win")
            If Quiz.HMC = 1 Then
                Me.Hide()
                Quiz.Show()
                Quiz.Score = Quiz.Score + 10 - er
                Quiz.HMC = 2
                Quiz.CheckHM()
                PictureBox14.Visible = True
            End If
            reset()
        End If
    End Sub

    Private Sub PictureBox13_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox13.Click
        Close()
    End Sub

    Private Sub PictureBox12_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox12.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub Button2_Click_1(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        Button2_Click(sender, e)
    End Sub

    Private Sub Button3_Click_1(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        Button3_Click(sender, e)
    End Sub

    Private Sub Button4_Click_1(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        Button4_Click(sender, e)
    End Sub


    Private Sub TB18C()
        TextBox18.WordWrap = False
        If word = "float" Then TextBox18.Text = "Tipo de Variavel que pode armazenar valores decimais"
        If word = "if" Then TextBox18.Text = "Palavra que dá inico à escrita de uma condição"
        If word = "for" Then TextBox18.Text = "Palavra que dá inicio à escrita de um loop"
        If word = "array" Then TextBox18.Text = "Tipo de variavél que guarda multiplos valores"
        TextBox18.WordWrap = True
    End Sub

    Private Sub PictureBox14_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox14.MouseEnter
        TextBox16.Visible = True

    End Sub
    Private Sub PictureBox14_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox14.MouseLeave
        TextBox16.Visible = False
    End Sub

    Private Sub PictureBox15_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox15.MouseEnter
        TB18C()
        TextBox18.Visible = True
    End Sub
    Private Sub PictureBox15_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox15.MouseLeave
        TB18C()
        TextBox18.Visible = False
    End Sub
End Class
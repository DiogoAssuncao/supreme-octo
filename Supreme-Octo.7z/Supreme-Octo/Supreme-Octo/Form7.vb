﻿Public Class Form7

    Private Sub PictureBox1_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox1.Click
        Me.Hide()
        Form3.Show()
    End Sub

    Private Sub PictureBox2_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox2.Click
        Close()
    End Sub

    Private Sub PictureBox3_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox3.Click
        Me.Hide()
        Form1.Show()
    End Sub

    Private Sub Form7_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Label1.Text = Form1.USERNAME
        TextBox1.Text = "Escreve 'Ajuda'"
    End Sub
    Private Sub TextBox2_KeyDown(sender As Object, e As System.Windows.Forms.KeyEventArgs) Handles TextBox2.KeyDown
        If e.KeyCode = Keys.Enter Then
            Button1.PerformClick()
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        TextBox1.Text = TextBox1.Text + "" + vbCrLf
        If TextBox2.Text = "Ajuda" Then
            TextBox1.Text = TextBox1.Text + "Escreve 'cat' seguido de uma categoria para escolheres." + vbCrLf
            TextBox1.Text = TextBox1.Text + "ex: cat Quiz" + vbCrLf
            TextBox1.Text = TextBox1.Text + "Escreve cat sozinho para veres as categorias Possiveis." + vbCrLf
        End If
        If TextBox2.Text = "cat" Then
            TextBox1.Text = TextBox1.Text + "Jogar" + vbCrLf
            TextBox1.Text = TextBox1.Text + "Quiz" + vbCrLf
            TextBox1.Text = TextBox1.Text + "Calculadora" + vbCrLf
        End If
        If TextBox2.Text = "cat Quiz" Then
            Me.Hide()
            Quiz.Show()
        End If
        If TextBox2.Text = "cat Calculadora" Then
            Me.Hide()
            Form6.Show()
        End If
        If TextBox2.Text = "cat Jogar" Then
            TextBox1.Text = TextBox1.Text + "cat Jogar Galo" + vbCrLf
            TextBox1.Text = TextBox1.Text + "ou" + vbCrLf
            TextBox1.Text = TextBox1.Text + "cat Jogar HangMan" + vbCrLf
        End If
        If TextBox2.Text = "cat Jogar Galo" Then
            Me.Hide()
            TTT.Show()
        End If
        If TextBox2.Text = "cat Jogar HangMan" Then
            Me.Hide()
            HangMan.Show()
        End If
        TextBox2.Clear()
    End Sub
End Class
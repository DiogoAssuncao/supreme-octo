﻿Imports System.IO
Public Class Quiz
    Public HMC As Integer = 0
    Dim a1 As Integer = 0, a2 As Integer = 0, a3 As Integer = 0, a4 As Integer = 0, a5 As Integer = 0, a6 As Integer = 0, a7 As Integer = 0
    Dim NxtCnt As Integer = 0
    Public Score As Integer = 0
    Dim Q1 As Integer
    Dim k As Integer = 0
    Private Sub Quiz_MouseClick1(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox1.MouseClick
        Dim R1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim R2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim R3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim R4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        If R1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If R2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If R3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If R4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
    End Sub
    Private Sub Quiz_MouseClick2(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox2.MouseClick
        Dim R1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim R2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim R3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim R4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        If R1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If R2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If R3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If R4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
    End Sub
    Private Sub Quiz_MouseClick3(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox3.MouseClick
        Dim R1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim R2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim R3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim R4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        If R1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If R2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If R3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If R4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
    End Sub
    Private Sub Quiz_MouseClick4(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox4.MouseClick
        Dim R1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim R2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim R3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim R4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        If R1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If R2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If R3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If R4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
    End Sub
    Private Sub Quiz_MouseClick5(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox5.MouseClick
        Dim R1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim R2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim R3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim R4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        If R1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If R2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If R3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If R4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
    End Sub
    Private Sub Quiz_MouseClick6(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox6.MouseClick
        Dim R1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim R2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim R3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim R4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        If R1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If R2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If R3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If R4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
    End Sub
    Private Sub Quiz_MouseClick7(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles PictureBox7.MouseClick
        Dim R1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim R2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim R3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim R4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        If R1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If R2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If R3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If R4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
    End Sub
    Private Function GetRandomInt(min As Int32, max As Int32) As Int32
        Static staticRandomGenerator As New System.Random
        Return staticRandomGenerator.Next(min, max + 1)
    End Function
    Private Sub Reset1()
        PictureBox8.Visible = False
        PictureBox9.Visible = False
        PictureBox10.Visible = False
        PictureBox11.Visible = False
        PictureBox13.Visible = False
        PictureBox14.Visible = False
        PictureBox15.Visible = False
        PictureBox16.Visible = False
        PictureBox17.Visible = False
        PictureBox18.Visible = False
        PictureBox19.Visible = False
        PictureBox20.Visible = False
    End Sub
    Private Sub Reset3()
        a1 = 0
        a2 = 0
        a3 = 0
        a4 = 0
        a5 = 0
        a6 = 0
        a7 = 0
    End Sub
    Private Sub Reset()
        PictureBox1.Visible = False
        PictureBox2.Visible = False
        PictureBox3.Visible = False
        PictureBox4.Visible = False
        PictureBox5.Visible = False
        PictureBox6.Visible = False
        PictureBox7.Visible = False
    End Sub
    Private Sub OpQu(ByVal Q As Integer)
        Reset()
        If Q = 1 Then
            If a1 = 0 Then
                PictureBox1.Visible = True
                a1 = 1
            Else
                Button5.PerformClick()
            End If
        End If
        If Q = 2 Then
            If a2 = 0 Then
                PictureBox2.Visible = True
                a2 = 1
            Else
                Button5.PerformClick()
            End If
        End If
        If Q = 3 Then
            If a3 = 0 Then
                PictureBox3.Visible = True
                a3 = 1
            Else
                Button5.PerformClick()
            End If
        End If
        If Q = 4 Then
            If a4 = 0 Then
                PictureBox4.Visible = True
                a4 = 1
            Else
                Button5.PerformClick()
            End If
        End If
        If Q = 5 Then
            If a5 = 0 Then
                PictureBox5.Visible = True
                a5 = 1
            Else
                Button5.PerformClick()
            End If
        End If
        If Q = 6 Then
            If a6 = 0 Then
                PictureBox6.Visible = True
                a6 = 1
            Else
                Button5.PerformClick()
            End If
        End If
        If Q = 7 Then
            If a7 = 0 Then
                PictureBox7.Visible = True
                a7 = 1
            Else
                Button5.PerformClick()
            End If
        End If
    End Sub
    Private Sub Quiz_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Q1 = GetRandomInt(1, 7)
        OpQu(Q1)
    End Sub

    Public Sub CheckHM()
        If HMC = 2 Then
            MsgBox("Score : " + Score.ToString)
            HMC = 0
            Score = 0
            HangMan.PictureBox12.Visible = True
            HangMan.reset()
            Reset()
            Reset1()
            Reset3()
            NxtCnt = 0
            Button5.PerformClick()
            NxtCnt = 0
            Me.Hide()
            Form3.Show()

        End If
    End Sub

    Function RndWrd()
        Dim a As String
        Dim ioFile As New StreamReader("C:\Supreme-Octo\HMWords.txt")
        Dim lines As New List(Of String)
        Dim rnd As New Random()
        Dim line As Integer
        While ioFile.Peek <> -1
            lines.Add(ioFile.ReadLine())
        End While
        line = rnd.Next(lines.Count + 1)
        a = lines(line).Trim()
        ioFile.Close()
        ioFile.Dispose()
        Return a
    End Function

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        If NxtCnt < 3 Then
            Q1 = GetRandomInt(1, 7)
            OpQu(Q1)
            NxtCnt += 1
            Reset1()
            Button5.Visible = False
            k = 0
        Else
            CheckHM()
            HangMan.TextBox1.Text = RndWrd()
            HangMan.Button2_Click(sender, e)
            Me.Hide()
            HangMan.Show()
            HMC = 1
            HangMan.Check()
            'MsgBox("Score:" + Score.ToString)
            'Me.Hide()
            'Form3.Show()
        End If
    End Sub
    ' 8 - 11   E
    '13 - 16   C
    '17 - 20   EC
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If k = 0 Then
            If Q1 = 1 Then
                PictureBox8.Visible = True
                PictureBox20.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 2 Then
                PictureBox8.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 3 Then
                PictureBox8.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 4 Then
                PictureBox8.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 5 Then
                PictureBox8.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 6 Then
                PictureBox8.Visible = True
                PictureBox19.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 7 Then
                PictureBox8.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        If k = 0 Then
            If Q1 = 1 Then
                PictureBox9.Visible = True
                PictureBox20.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 2 Then
                PictureBox14.Visible = True
                k = 1
                Button5.Visible = True
                Score += 1
            End If
            If Q1 = 3 Then
                PictureBox14.Visible = True
                k = 1
                Button5.Visible = True
                Score += 1
            End If
            If Q1 = 4 Then
                PictureBox14.Visible = True
                k = 1
                Button5.Visible = True
                Score += 1
            End If
            If Q1 = 5 Then
                PictureBox14.Visible = True
                k = 1
                Button5.Visible = True
                Score += 1
            End If
            If Q1 = 6 Then
                PictureBox9.Visible = True
                PictureBox19.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 7 Then
                PictureBox14.Visible = True
                k = 1
                Button5.Visible = True
                Score += 1
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        If k = 0 Then
            If Q1 = 1 Then
                PictureBox9.Visible = True
                PictureBox20.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 2 Then
                PictureBox9.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 3 Then
                PictureBox9.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 4 Then
                PictureBox9.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 5 Then
                PictureBox9.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
            If Q1 = 6 Then
                PictureBox15.Visible = True
                k = 1
                Button5.Visible = True
                Score += 1
            End If
            If Q1 = 7 Then
                PictureBox9.Visible = True
                PictureBox18.Visible = True
                k = 1
                Button5.Visible = True
            End If
        End If
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If k = 0 Then
            If Q1 = 1 Then
                PictureBox16.Visible = True
                Button5.Visible = True
                Score += 1
                k = 1
            End If
            If Q1 = 2 Then
                PictureBox10.Visible = True
                PictureBox18.Visible = True
                Button5.Visible = True
                k = 1
            End If
            If Q1 = 3 Then
                PictureBox10.Visible = True
                PictureBox18.Visible = True
                Button5.Visible = True
                k = 1
            End If
            If Q1 = 4 Then
                PictureBox10.Visible = True
                PictureBox18.Visible = True
                Button5.Visible = True
                k = 1
            End If
            If Q1 = 5 Then
                PictureBox10.Visible = True
                PictureBox18.Visible = True
                Button5.Visible = True
                k = 1
            End If
            If Q1 = 6 Then
                PictureBox10.Visible = True
                PictureBox19.Visible = True
                Button5.Visible = True
                k = 1
            End If
            If Q1 = 7 Then
                PictureBox10.Visible = True
                PictureBox18.Visible = True
                Button5.Visible = True
                k = 1
            End If
        End If
    End Sub

    Private Sub PictureBox12_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox12.Click
        Close()
    End Sub
End Class
﻿Public Class TTT
    Private Sub TieChecker()
        If c1 <> 0 And c2 <> 0 And c3 <> 0 And c4 <> 0 And c5 <> 0 And c6 <> 0 And
            c7 <> 0 And c8 <> 0 And c9 <> 0 Then
            Button1.Visible = False
            Button2.Visible = False
            Button3.Visible = False
            Button4.Visible = False
            Button5.Visible = False
            Button6.Visible = False
            Button7.Visible = False
            Button8.Visible = False
            Button9.Visible = False
            MsgBox("Empate!")
            Button10.PerformClick()
        End If
    End Sub
    Private Sub Checker()
        If c1 = c2 And c2 = c3 Then
            Button1.Visible = False
            Button2.Visible = False
            Button3.Visible = False
            If c1 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c1 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
        If c4 = c5 And c5 = c6 Then
            Button4.Visible = False
            Button5.Visible = False
            Button6.Visible = False
            If c4 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c4 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
        If c7 = c8 And c8 = c9 Then
            Button7.Visible = False
            Button8.Visible = False
            Button9.Visible = False
            If c7 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c7 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
        If c1 = c4 And c4 = c7 Then
            Button1.Visible = False
            Button4.Visible = False
            Button7.Visible = False
            If c1 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c1 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
        If c2 = c5 And c5 = c8 Then
            Button2.Visible = False
            Button5.Visible = False
            Button8.Visible = False
            If c2 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c2 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
        If c3 = c6 And c6 = c9 Then
            Button3.Visible = False
            Button6.Visible = False
            Button9.Visible = False
            If c3 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c3 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
        If c1 = c5 And c5 = c9 Then
            Button1.Visible = False
            Button5.Visible = False
            Button9.Visible = False
            If c1 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c1 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
        If c3 = c5 And c5 = c7 Then
            Button3.Visible = False
            Button5.Visible = False
            Button7.Visible = False
            If c3 = 1 Then
                MsgBox("Jogador 1 Wins")
                Button10.PerformClick()
            End If
            If c3 = 2 Then
                MsgBox("Jogador 2 Wins")
                Button10.PerformClick()
            End If

        End If
    End Sub
    Dim Player, c1, c2, c3, c4, c5, c6, c7, c8, c9, A As Double
    Private Sub TTT_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseClick
        TieChecker()
        Checker()
        Dim B1 As Rectangle = New Rectangle(Button1.Left, Button1.Top, Button1.Width, Button1.Height)
        Dim B2 As Rectangle = New Rectangle(Button2.Left, Button2.Top, Button2.Width, Button2.Height)
        Dim B3 As Rectangle = New Rectangle(Button3.Left, Button3.Top, Button3.Width, Button3.Height)
        Dim B4 As Rectangle = New Rectangle(Button4.Left, Button4.Top, Button4.Width, Button4.Height)
        Dim B5 As Rectangle = New Rectangle(Button5.Left, Button5.Top, Button5.Width, Button5.Height)
        Dim B6 As Rectangle = New Rectangle(Button6.Left, Button6.Top, Button6.Width, Button6.Height)
        Dim B7 As Rectangle = New Rectangle(Button7.Left, Button7.Top, Button7.Width, Button7.Height)
        Dim B8 As Rectangle = New Rectangle(Button8.Left, Button8.Top, Button8.Width, Button8.Height)
        Dim B9 As Rectangle = New Rectangle(Button9.Left, Button9.Top, Button9.Width, Button9.Height)
        If B1.Contains(e.X, e.Y) Then
            Button1.Visible = True
            Button1.PerformClick()
            Button1.Visible = False
        End If
        If B2.Contains(e.X, e.Y) Then
            Button2.Visible = True
            Button2.PerformClick()
            Button2.Visible = False
        End If
        If B3.Contains(e.X, e.Y) Then
            Button3.Visible = True
            Button3.PerformClick()
            Button3.Visible = False
        End If
        If B4.Contains(e.X, e.Y) Then
            Button4.Visible = True
            Button4.PerformClick()
            Button4.Visible = False
        End If
        If B5.Contains(e.X, e.Y) Then
            Button5.Visible = True
            Button5.PerformClick()
            Button5.Visible = False
        End If
        If B6.Contains(e.X, e.Y) Then
            Button6.Visible = True
            Button6.PerformClick()
            Button6.Visible = False
        End If
        If B7.Contains(e.X, e.Y) Then
            Button7.Visible = True
            Button7.PerformClick()
            Button7.Visible = False
        End If
        If B8.Contains(e.X, e.Y) Then
            Button8.Visible = True
            Button8.PerformClick()
            Button8.Visible = False
        End If
        If B9.Contains(e.X, e.Y) Then
            Button9.Visible = True
            Button9.PerformClick()
            Button9.Visible = False
        End If

    End Sub


    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        If c1 <> 1 Or c1 <> 2 Then
            If Player = 1 Then
                PictureBox2.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c1 = 1
            Else
                PictureBox3.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c1 = 2
            End If
            TieChecker()
            Checker()
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        If c2 <> 1 Or c2 <> 2 Then
            If Player = 1 Then
                PictureBox4.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c2 = 1
            Else
                PictureBox5.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c2 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Button3_Click(sender As System.Object, e As System.EventArgs) Handles Button3.Click
        If c3 <> 1 Or c3 <> 2 Then
            If Player = 1 Then
                PictureBox6.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c3 = 1
            Else
                PictureBox7.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c3 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        If c4 <> 1 Or c4 <> 2 Then
            If Player = 1 Then
                PictureBox8.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c4 = 1
            Else
                PictureBox9.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c4 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Button5_Click(sender As System.Object, e As System.EventArgs) Handles Button5.Click
        If c5 <> 1 Or c5 <> 2 Then
            If Player = 1 Then
                PictureBox10.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c5 = 1
            Else
                PictureBox11.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c5 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Button6_Click(sender As System.Object, e As System.EventArgs) Handles Button6.Click
        If c6 <> 1 Or c6 <> 2 Then
            If Player = 1 Then
                PictureBox12.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c6 = 1
            Else
                PictureBox13.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c6 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Button7_Click(sender As System.Object, e As System.EventArgs) Handles Button7.Click
        If c7 <> 1 Or c7 <> 2 Then
            If Player = 1 Then
                PictureBox14.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c7 = 1
            Else
                PictureBox15.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c7 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Button8_Click(sender As System.Object, e As System.EventArgs) Handles Button8.Click
        If c8 <> 1 Or c8 <> 2 Then
            If Player = 1 Then
                PictureBox16.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c8 = 1
            Else
                PictureBox17.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c8 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Button9_Click(sender As System.Object, e As System.EventArgs) Handles Button9.Click
        If c9 <> 1 Or c9 <> 2 Then
            If Player = 1 Then
                PictureBox18.Visible = True
                Player = 2
                Label1.Text = "Jogador 2"
                c9 = 1
            Else
                PictureBox19.Visible = True
                Player = 1
                Label1.Text = "Jogador 1"
                c9 = 2
            End If
            Checker()
            TieChecker()
        End If
    End Sub

    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Player = 1
        c1 = 0
        c2 = 0
        c3 = 0
        c4 = 0
        c5 = 0
        c6 = 0
        c7 = 0
        c8 = 0
        c9 = 0
    End Sub

    Private Sub Button10_Click(sender As System.Object, e As System.EventArgs) Handles Button10.Click
        Label1.Text = "Jogador 1"
        Player = 1
        A = 0
        c1 = 0
        c2 = 0
        c3 = 0
        c4 = 0
        c5 = 0
        c6 = 0
        c7 = 0
        c8 = 0
        c9 = 0
        PictureBox2.Visible = False
        PictureBox3.Visible = False
        PictureBox4.Visible = False
        PictureBox5.Visible = False
        PictureBox6.Visible = False
        PictureBox7.Visible = False
        PictureBox8.Visible = False
        PictureBox9.Visible = False
        PictureBox10.Visible = False
        PictureBox11.Visible = False
        PictureBox12.Visible = False
        PictureBox13.Visible = False
        PictureBox14.Visible = False
        PictureBox15.Visible = False
        PictureBox16.Visible = False
        PictureBox17.Visible = False
        PictureBox18.Visible = False
        PictureBox19.Visible = False
    End Sub

    Private Sub PictureBox20_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox20.Click
        Close()
    End Sub

    Private Sub PictureBox21_Click(sender As System.Object, e As System.EventArgs) Handles PictureBox21.Click
        Me.Hide()
        Form5.Show()
    End Sub

    Private Sub PicBox_Click(sender As System.Object, e As System.EventArgs) Handles PicBox.Click
        Label1.Text = "Jogador 1"
        Player = 1
        A = 0
        c1 = 0
        c2 = 0
        c3 = 0
        c4 = 0
        c5 = 0
        c6 = 0
        c7 = 0
        c8 = 0
        c9 = 0
        PictureBox2.Visible = False
        PictureBox3.Visible = False
        PictureBox4.Visible = False
        PictureBox5.Visible = False
        PictureBox6.Visible = False
        PictureBox7.Visible = False
        PictureBox8.Visible = False
        PictureBox9.Visible = False
        PictureBox10.Visible = False
        PictureBox11.Visible = False
        PictureBox12.Visible = False
        PictureBox13.Visible = False
        PictureBox14.Visible = False
        PictureBox15.Visible = False
        PictureBox16.Visible = False
        PictureBox17.Visible = False
        PictureBox18.Visible = False
        PictureBox19.Visible = False
    End Sub
End Class
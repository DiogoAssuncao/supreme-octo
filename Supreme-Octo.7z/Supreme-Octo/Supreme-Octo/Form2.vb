﻿Imports System.IO
Public Class Form2
    Dim Leitor As StreamReader
    Public x As String = "C:\Supreme-Octo\Login"

    Private Sub Form1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Backround.MouseClick
        Dim RegistarA As Rectangle = New Rectangle(Registar.Left, Registar.Top, Registar.Width, Registar.Height)
        Dim CancelarA As Rectangle = New Rectangle(Cancelar.Left, Cancelar.Top, Cancelar.Width, Cancelar.Height)
        If RegistarA.Contains(e.X, e.Y) Then
            Registar.Visible = True
            Registar.PerformClick()
            Registar.Visible = False
        End If
        If CancelarA.Contains(e.X, e.Y) Then
            Cancelar.Visible = True
            Cancelar.PerformClick()
            Cancelar.Visible = False
        End If
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If Not File.Exists(x) Then
            Dim y As FileStream
            y = File.Create(x)
            y.Close()
        End If
    End Sub
    Public CheckUI As Integer = 0
    Private Sub CheckU()
        Dim z As String
        Dim kk As Integer = 0
        Leitor = File.OpenText(x)
        While Leitor.Peek <> -1
            z = Leitor.ReadLine()
            If TextBox1.Text = z Then
                CheckUI = 1
            End If
            z = Leitor.ReadLine()
        End While
        Leitor.Close()
    End Sub

    Private Sub Registar_Click(sender As System.Object, e As System.EventArgs) Handles Registar.Click
        If TextBox1.Text = Nothing Or
    TextBox2.Text = Nothing Then
            MsgBox("Insira um Username e uma Password!")
        Else
            CheckU()
            If CheckUI = 0 Then
                File.AppendAllText(x, TextBox1.Text & vbCrLf)
                File.AppendAllText(x, TextBox2.Text & vbCrLf)
                MsgBox("Dados Guardados!")
                Me.Hide()
                Form1.Show()
                TextBox1.Clear()
                TextBox2.Clear()
            Else
                MsgBox("Username já está em uso!")
                CheckUI = 0
            End If
        End If
    End Sub

    Private Sub Cancelar_Click(sender As System.Object, e As System.EventArgs) Handles Cancelar.Click
        Me.Hide()
        Form1.Show()
    End Sub
End Class
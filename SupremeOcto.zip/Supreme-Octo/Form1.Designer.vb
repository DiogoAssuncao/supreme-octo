﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.RB1 = New System.Windows.Forms.Button()
        Me.RB2 = New System.Windows.Forms.Button()
        Me.RB3 = New System.Windows.Forms.Button()
        Me.RB4 = New System.Windows.Forms.Button()
        Me.RB5 = New System.Windows.Forms.Button()
        Me.RB6 = New System.Windows.Forms.Button()
        Me.RB7 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Login = New System.Windows.Forms.Button()
        Me.Cancelar = New System.Windows.Forms.Button()
        Me.Backround = New System.Windows.Forms.PictureBox()
        CType(Me.Backround, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("OCR A Extended", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(37, 128)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(161, 20)
        Me.TextBox1.TabIndex = 1
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(38, 186)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBox2.Size = New System.Drawing.Size(161, 22)
        Me.TextBox2.TabIndex = 2
        '
        'RB1
        '
        Me.RB1.Location = New System.Drawing.Point(190, 280)
        Me.RB1.Name = "RB1"
        Me.RB1.Size = New System.Drawing.Size(76, 67)
        Me.RB1.TabIndex = 5
        Me.RB1.Text = "Button1"
        Me.RB1.UseVisualStyleBackColor = True
        Me.RB1.Visible = False
        '
        'RB2
        '
        Me.RB2.Location = New System.Drawing.Point(154, 311)
        Me.RB2.Name = "RB2"
        Me.RB2.Size = New System.Drawing.Size(44, 35)
        Me.RB2.TabIndex = 6
        Me.RB2.Text = "Button2"
        Me.RB2.UseVisualStyleBackColor = True
        Me.RB2.Visible = False
        '
        'RB3
        '
        Me.RB3.Location = New System.Drawing.Point(222, 241)
        Me.RB3.Name = "RB3"
        Me.RB3.Size = New System.Drawing.Size(43, 49)
        Me.RB3.TabIndex = 7
        Me.RB3.Text = "Button3"
        Me.RB3.UseVisualStyleBackColor = True
        Me.RB3.Visible = False
        '
        'RB4
        '
        Me.RB4.Location = New System.Drawing.Point(135, 324)
        Me.RB4.Name = "RB4"
        Me.RB4.Size = New System.Drawing.Size(75, 23)
        Me.RB4.TabIndex = 8
        Me.RB4.Text = "Button4"
        Me.RB4.UseVisualStyleBackColor = True
        Me.RB4.Visible = False
        '
        'RB5
        '
        Me.RB5.Location = New System.Drawing.Point(171, 294)
        Me.RB5.Name = "RB5"
        Me.RB5.Size = New System.Drawing.Size(82, 38)
        Me.RB5.TabIndex = 9
        Me.RB5.Text = "Registar"
        Me.RB5.UseVisualStyleBackColor = True
        Me.RB5.Visible = False
        '
        'RB6
        '
        Me.RB6.Location = New System.Drawing.Point(203, 265)
        Me.RB6.Name = "RB6"
        Me.RB6.Size = New System.Drawing.Size(75, 23)
        Me.RB6.TabIndex = 10
        Me.RB6.Text = "Button6"
        Me.RB6.UseVisualStyleBackColor = True
        Me.RB6.Visible = False
        '
        'RB7
        '
        Me.RB7.Location = New System.Drawing.Point(242, 225)
        Me.RB7.Name = "RB7"
        Me.RB7.Size = New System.Drawing.Size(24, 23)
        Me.RB7.TabIndex = 11
        Me.RB7.Text = "Button7"
        Me.RB7.UseVisualStyleBackColor = True
        Me.RB7.Visible = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(167, Byte), Integer), CType(CType(167, Byte), Integer))
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Image = Global.WindowsApplication1.My.Resources.Resources._botão__entrar
        Me.Button1.Location = New System.Drawing.Point(37, 218)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(68, 46)
        Me.Button1.TabIndex = 4
        Me.Button1.UseVisualStyleBackColor = False
        Me.Button1.Visible = False
        '
        'Login
        '
        Me.Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Login.Image = Global.WindowsApplication1.My.Resources.Resources._botão__entrar
        Me.Login.Location = New System.Drawing.Point(37, 218)
        Me.Login.Name = "Login"
        Me.Login.Size = New System.Drawing.Size(68, 36)
        Me.Login.TabIndex = 4
        Me.Login.UseVisualStyleBackColor = True
        Me.Login.Visible = False
        '
        'Cancelar
        '
        Me.Cancelar.BackColor = System.Drawing.Color.FromArgb(CType(CType(167, Byte), Integer), CType(CType(167, Byte), Integer), CType(CType(167, Byte), Integer))
        Me.Cancelar.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._botão__cancelar
        Me.Cancelar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Cancelar.Image = Global.WindowsApplication1.My.Resources.Resources._botão__cancelar
        Me.Cancelar.Location = New System.Drawing.Point(135, 218)
        Me.Cancelar.Name = "Cancelar"
        Me.Cancelar.Size = New System.Drawing.Size(67, 46)
        Me.Cancelar.TabIndex = 3
        Me.Cancelar.UseVisualStyleBackColor = False
        Me.Cancelar.Visible = False
        '
        'Backround
        '
        Me.Backround.Image = CType(resources.GetObject("Backround.Image"), System.Drawing.Image)
        Me.Backround.Location = New System.Drawing.Point(0, -1)
        Me.Backround.Name = "Backround"
        Me.Backround.Size = New System.Drawing.Size(326, 399)
        Me.Backround.TabIndex = 0
        Me.Backround.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(262, 342)
        Me.Controls.Add(Me.RB7)
        Me.Controls.Add(Me.RB6)
        Me.Controls.Add(Me.RB5)
        Me.Controls.Add(Me.RB4)
        Me.Controls.Add(Me.RB3)
        Me.Controls.Add(Me.RB2)
        Me.Controls.Add(Me.RB1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Login)
        Me.Controls.Add(Me.Cancelar)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Backround)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        CType(Me.Backround, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Backround As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Login As System.Windows.Forms.Button
    Friend WithEvents RB1 As System.Windows.Forms.Button
    Friend WithEvents RB2 As System.Windows.Forms.Button
    Friend WithEvents RB3 As System.Windows.Forms.Button
    Friend WithEvents RB4 As System.Windows.Forms.Button
    Friend WithEvents RB5 As System.Windows.Forms.Button
    Friend WithEvents RB6 As System.Windows.Forms.Button
    Friend WithEvents RB7 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Cancelar As System.Windows.Forms.Button

End Class

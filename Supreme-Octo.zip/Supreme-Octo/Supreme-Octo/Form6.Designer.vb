﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form6))
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.ButtonMa = New System.Windows.Forms.Button()
        Me.ButtonF = New System.Windows.Forms.Button()
        Me.ButtonV = New System.Windows.Forms.Button()
        Me.ButtonMe = New System.Windows.Forms.Button()
        Me.ButtonEnt = New System.Windows.Forms.Button()
        Me.ButtonClr = New System.Windows.Forms.Button()
        Me.ButtonDel = New System.Windows.Forms.Button()
        Me.ButtonDelete = New System.Windows.Forms.Button()
        Me.ButtonDot = New System.Windows.Forms.Button()
        Me.ButtonClear = New System.Windows.Forms.Button()
        Me.ButtonMult = New System.Windows.Forms.Button()
        Me.ButtonDiv = New System.Windows.Forms.Button()
        Me.ButtonEnter = New System.Windows.Forms.Button()
        Me.ButtonMenos = New System.Windows.Forms.Button()
        Me.ButtonMais = New System.Windows.Forms.Button()
        Me.Button0 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.TextBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox3.Location = New System.Drawing.Point(468, 22)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(192, 58)
        Me.TextBox3.TabIndex = 58
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox2.Location = New System.Drawing.Point(240, 12)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.ReadOnly = True
        Me.TextBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.TextBox2.Size = New System.Drawing.Size(202, 350)
        Me.TextBox2.TabIndex = 50
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(126, Byte), Integer), CType(CType(248, Byte), Integer), CType(CType(105, Byte), Integer))
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.TextBox1.Location = New System.Drawing.Point(25, 22)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(192, 58)
        Me.TextBox1.TabIndex = 31
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), System.Drawing.Image)
        Me.PictureBox4.Location = New System.Drawing.Point(12, 368)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(44, 40)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 62
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.WindowsApplication1.My.Resources.Resources.XXX1
        Me.PictureBox3.Location = New System.Drawing.Point(635, 368)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(52, 51)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 61
        Me.PictureBox3.TabStop = False
        '
        'Button11
        '
        Me.Button11.FlatAppearance.BorderSize = 0
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.Location = New System.Drawing.Point(570, 280)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(90, 38)
        Me.Button11.TabIndex = 60
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.FlatAppearance.BorderSize = 0
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.Location = New System.Drawing.Point(481, 280)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(83, 38)
        Me.Button10.TabIndex = 59
        Me.Button10.UseVisualStyleBackColor = True
        '
        'ButtonMa
        '
        Me.ButtonMa.FlatAppearance.BorderSize = 0
        Me.ButtonMa.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMa.Image = CType(resources.GetObject("ButtonMa.Image"), System.Drawing.Image)
        Me.ButtonMa.Location = New System.Drawing.Point(481, 192)
        Me.ButtonMa.Name = "ButtonMa"
        Me.ButtonMa.Size = New System.Drawing.Size(170, 38)
        Me.ButtonMa.TabIndex = 57
        Me.ButtonMa.UseVisualStyleBackColor = True
        '
        'ButtonF
        '
        Me.ButtonF.FlatAppearance.BorderSize = 0
        Me.ButtonF.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonF.Image = CType(resources.GetObject("ButtonF.Image"), System.Drawing.Image)
        Me.ButtonF.Location = New System.Drawing.Point(481, 148)
        Me.ButtonF.Name = "ButtonF"
        Me.ButtonF.Size = New System.Drawing.Size(170, 38)
        Me.ButtonF.TabIndex = 56
        Me.ButtonF.UseVisualStyleBackColor = True
        '
        'ButtonV
        '
        Me.ButtonV.FlatAppearance.BorderSize = 0
        Me.ButtonV.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonV.Image = CType(resources.GetObject("ButtonV.Image"), System.Drawing.Image)
        Me.ButtonV.Location = New System.Drawing.Point(477, 104)
        Me.ButtonV.Name = "ButtonV"
        Me.ButtonV.Size = New System.Drawing.Size(174, 38)
        Me.ButtonV.TabIndex = 55
        Me.ButtonV.UseVisualStyleBackColor = True
        '
        'ButtonMe
        '
        Me.ButtonMe.FlatAppearance.BorderSize = 0
        Me.ButtonMe.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMe.Image = CType(resources.GetObject("ButtonMe.Image"), System.Drawing.Image)
        Me.ButtonMe.Location = New System.Drawing.Point(481, 236)
        Me.ButtonMe.Name = "ButtonMe"
        Me.ButtonMe.Size = New System.Drawing.Size(170, 38)
        Me.ButtonMe.TabIndex = 54
        Me.ButtonMe.UseVisualStyleBackColor = True
        '
        'ButtonEnt
        '
        Me.ButtonEnt.FlatAppearance.BorderSize = 0
        Me.ButtonEnt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonEnt.Image = CType(resources.GetObject("ButtonEnt.Image"), System.Drawing.Image)
        Me.ButtonEnt.Location = New System.Drawing.Point(536, 324)
        Me.ButtonEnt.Name = "ButtonEnt"
        Me.ButtonEnt.Size = New System.Drawing.Size(58, 38)
        Me.ButtonEnt.TabIndex = 53
        Me.ButtonEnt.UseVisualStyleBackColor = True
        '
        'ButtonClr
        '
        Me.ButtonClr.FlatAppearance.BorderSize = 0
        Me.ButtonClr.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonClr.Image = CType(resources.GetObject("ButtonClr.Image"), System.Drawing.Image)
        Me.ButtonClr.Location = New System.Drawing.Point(477, 324)
        Me.ButtonClr.Name = "ButtonClr"
        Me.ButtonClr.Size = New System.Drawing.Size(53, 38)
        Me.ButtonClr.TabIndex = 52
        Me.ButtonClr.UseVisualStyleBackColor = True
        '
        'ButtonDel
        '
        Me.ButtonDel.FlatAppearance.BorderSize = 0
        Me.ButtonDel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDel.Image = CType(resources.GetObject("ButtonDel.Image"), System.Drawing.Image)
        Me.ButtonDel.Location = New System.Drawing.Point(600, 324)
        Me.ButtonDel.Name = "ButtonDel"
        Me.ButtonDel.Size = New System.Drawing.Size(51, 38)
        Me.ButtonDel.TabIndex = 51
        Me.ButtonDel.UseVisualStyleBackColor = True
        '
        'ButtonDelete
        '
        Me.ButtonDelete.FlatAppearance.BorderSize = 0
        Me.ButtonDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDelete.Image = CType(resources.GetObject("ButtonDelete.Image"), System.Drawing.Image)
        Me.ButtonDelete.Location = New System.Drawing.Point(147, 324)
        Me.ButtonDelete.Name = "ButtonDelete"
        Me.ButtonDelete.Size = New System.Drawing.Size(55, 38)
        Me.ButtonDelete.TabIndex = 49
        Me.ButtonDelete.UseVisualStyleBackColor = True
        '
        'ButtonDot
        '
        Me.ButtonDot.FlatAppearance.BorderSize = 0
        Me.ButtonDot.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDot.Image = CType(resources.GetObject("ButtonDot.Image"), System.Drawing.Image)
        Me.ButtonDot.Location = New System.Drawing.Point(95, 280)
        Me.ButtonDot.Name = "ButtonDot"
        Me.ButtonDot.Size = New System.Drawing.Size(55, 38)
        Me.ButtonDot.TabIndex = 48
        Me.ButtonDot.UseVisualStyleBackColor = True
        '
        'ButtonClear
        '
        Me.ButtonClear.FlatAppearance.BorderSize = 0
        Me.ButtonClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonClear.Image = CType(resources.GetObject("ButtonClear.Image"), System.Drawing.Image)
        Me.ButtonClear.Location = New System.Drawing.Point(43, 324)
        Me.ButtonClear.Name = "ButtonClear"
        Me.ButtonClear.Size = New System.Drawing.Size(55, 38)
        Me.ButtonClear.TabIndex = 47
        Me.ButtonClear.UseVisualStyleBackColor = True
        '
        'ButtonMult
        '
        Me.ButtonMult.FlatAppearance.BorderSize = 0
        Me.ButtonMult.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMult.Image = CType(resources.GetObject("ButtonMult.Image"), System.Drawing.Image)
        Me.ButtonMult.Location = New System.Drawing.Point(147, 286)
        Me.ButtonMult.Name = "ButtonMult"
        Me.ButtonMult.Size = New System.Drawing.Size(55, 32)
        Me.ButtonMult.TabIndex = 46
        Me.ButtonMult.UseVisualStyleBackColor = True
        '
        'ButtonDiv
        '
        Me.ButtonDiv.FlatAppearance.BorderSize = 0
        Me.ButtonDiv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonDiv.Image = CType(resources.GetObject("ButtonDiv.Image"), System.Drawing.Image)
        Me.ButtonDiv.Location = New System.Drawing.Point(43, 280)
        Me.ButtonDiv.Name = "ButtonDiv"
        Me.ButtonDiv.Size = New System.Drawing.Size(55, 38)
        Me.ButtonDiv.TabIndex = 45
        Me.ButtonDiv.UseVisualStyleBackColor = True
        '
        'ButtonEnter
        '
        Me.ButtonEnter.FlatAppearance.BorderSize = 0
        Me.ButtonEnter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonEnter.Image = CType(resources.GetObject("ButtonEnter.Image"), System.Drawing.Image)
        Me.ButtonEnter.Location = New System.Drawing.Point(95, 324)
        Me.ButtonEnter.Name = "ButtonEnter"
        Me.ButtonEnter.Size = New System.Drawing.Size(55, 38)
        Me.ButtonEnter.TabIndex = 44
        Me.ButtonEnter.UseVisualStyleBackColor = True
        '
        'ButtonMenos
        '
        Me.ButtonMenos.FlatAppearance.BorderSize = 0
        Me.ButtonMenos.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMenos.Image = CType(resources.GetObject("ButtonMenos.Image"), System.Drawing.Image)
        Me.ButtonMenos.Location = New System.Drawing.Point(43, 236)
        Me.ButtonMenos.Name = "ButtonMenos"
        Me.ButtonMenos.Size = New System.Drawing.Size(55, 38)
        Me.ButtonMenos.TabIndex = 43
        Me.ButtonMenos.UseVisualStyleBackColor = True
        '
        'ButtonMais
        '
        Me.ButtonMais.FlatAppearance.BorderSize = 0
        Me.ButtonMais.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ButtonMais.Image = CType(resources.GetObject("ButtonMais.Image"), System.Drawing.Image)
        Me.ButtonMais.Location = New System.Drawing.Point(147, 236)
        Me.ButtonMais.Name = "ButtonMais"
        Me.ButtonMais.Size = New System.Drawing.Size(55, 38)
        Me.ButtonMais.TabIndex = 42
        Me.ButtonMais.UseVisualStyleBackColor = True
        '
        'Button0
        '
        Me.Button0.FlatAppearance.BorderSize = 0
        Me.Button0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button0.Image = CType(resources.GetObject("Button0.Image"), System.Drawing.Image)
        Me.Button0.Location = New System.Drawing.Point(95, 236)
        Me.Button0.Name = "Button0"
        Me.Button0.Size = New System.Drawing.Size(55, 38)
        Me.Button0.TabIndex = 41
        Me.Button0.UseVisualStyleBackColor = True
        '
        'Button9
        '
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Image = CType(resources.GetObject("Button9.Image"), System.Drawing.Image)
        Me.Button9.Location = New System.Drawing.Point(147, 192)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(55, 38)
        Me.Button9.TabIndex = 40
        Me.Button9.UseVisualStyleBackColor = True
        '
        'Button8
        '
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Image = CType(resources.GetObject("Button8.Image"), System.Drawing.Image)
        Me.Button8.Location = New System.Drawing.Point(95, 192)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(55, 38)
        Me.Button8.TabIndex = 39
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Image = CType(resources.GetObject("Button7.Image"), System.Drawing.Image)
        Me.Button7.Location = New System.Drawing.Point(43, 192)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(55, 38)
        Me.Button7.TabIndex = 38
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.Location = New System.Drawing.Point(147, 148)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(55, 38)
        Me.Button6.TabIndex = 37
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.Location = New System.Drawing.Point(95, 148)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(55, 38)
        Me.Button5.TabIndex = 36
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(43, 148)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(55, 38)
        Me.Button4.TabIndex = 35
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(147, 104)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(55, 38)
        Me.Button3.TabIndex = 34
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(95, 104)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(55, 38)
        Me.Button2.TabIndex = 33
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(43, 104)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(55, 38)
        Me.Button1.TabIndex = 32
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form6
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(16, Byte), Integer), CType(CType(16, Byte), Integer), CType(CType(16, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(690, 418)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.ButtonMa)
        Me.Controls.Add(Me.ButtonF)
        Me.Controls.Add(Me.ButtonV)
        Me.Controls.Add(Me.ButtonMe)
        Me.Controls.Add(Me.ButtonEnt)
        Me.Controls.Add(Me.ButtonClr)
        Me.Controls.Add(Me.ButtonDel)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.ButtonDelete)
        Me.Controls.Add(Me.ButtonDot)
        Me.Controls.Add(Me.ButtonClear)
        Me.Controls.Add(Me.ButtonMult)
        Me.Controls.Add(Me.ButtonDiv)
        Me.Controls.Add(Me.ButtonEnter)
        Me.Controls.Add(Me.ButtonMenos)
        Me.Controls.Add(Me.ButtonMais)
        Me.Controls.Add(Me.Button0)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form6"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form6"
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonMa As System.Windows.Forms.Button
    Friend WithEvents ButtonF As System.Windows.Forms.Button
    Friend WithEvents ButtonV As System.Windows.Forms.Button
    Friend WithEvents ButtonMe As System.Windows.Forms.Button
    Friend WithEvents ButtonEnt As System.Windows.Forms.Button
    Friend WithEvents ButtonClr As System.Windows.Forms.Button
    Friend WithEvents ButtonDel As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents ButtonDelete As System.Windows.Forms.Button
    Friend WithEvents ButtonDot As System.Windows.Forms.Button
    Friend WithEvents ButtonClear As System.Windows.Forms.Button
    Friend WithEvents ButtonMult As System.Windows.Forms.Button
    Friend WithEvents ButtonDiv As System.Windows.Forms.Button
    Friend WithEvents ButtonEnter As System.Windows.Forms.Button
    Friend WithEvents ButtonMenos As System.Windows.Forms.Button
    Friend WithEvents ButtonMais As System.Windows.Forms.Button
    Friend WithEvents Button0 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
End Class

﻿Imports System.IO
Public Class Form1
    Public USERNAME As String
    Dim Leitor As StreamReader
    Public x As String = "C:\Supreme-Octo\Login"
    Dim z As String

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not File.Exists(x) Then
            Dim y As FileStream
            y = File.Create(x)
            y.Close()
        End If
    End Sub

    Private Sub Form1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Backround.MouseClick
        Dim CancelarA As Rectangle = New Rectangle(Cancelar.Left, Cancelar.Top, Cancelar.Width, Cancelar.Height)
        Dim LoginA As Rectangle = New Rectangle(Login.Left, Login.Top, Login.Width, Login.Height)
        Dim ARB1 As Rectangle = New Rectangle(RB1.Left, RB1.Top, RB1.Width, RB1.Height)
        Dim ARB2 As Rectangle = New Rectangle(RB2.Left, RB2.Top, RB2.Width, RB2.Height)
        Dim ARB3 As Rectangle = New Rectangle(RB3.Left, RB3.Top, RB3.Width, RB3.Height)
        Dim ARB4 As Rectangle = New Rectangle(RB4.Left, RB4.Top, RB4.Width, RB4.Height)
        Dim ARB5 As Rectangle = New Rectangle(RB5.Left, RB5.Top, RB5.Width, RB5.Height)
        Dim ARB6 As Rectangle = New Rectangle(RB6.Left, RB6.Top, RB6.Width, RB6.Height)
        Dim ARB7 As Rectangle = New Rectangle(RB7.Left, RB7.Top, RB7.Width, RB7.Height)
        If CancelarA.Contains(e.X, e.Y) Then
            Cancelar.Visible = True
            Cancelar.PerformClick()
            Cancelar.Visible = False
        End If
        If LoginA.Contains(e.X, e.Y) Then
            Login.Visible = True
            Login.PerformClick()
            Login.Visible = False
        End If
        If ARB1.Contains(e.X, e.Y) Or ARB2.Contains(e.X, e.Y) Or ARB3.Contains(e.X, e.Y) Or ARB4.Contains(e.X, e.Y) Or ARB5.Contains(e.X, e.Y) Or ARB6.Contains(e.X, e.Y) Or
            ARB7.Contains(e.X, e.Y) Then
            RB1.Visible = True
            RB2.Visible = True
            RB3.Visible = True
            RB4.Visible = True
            RB5.Visible = True
            RB6.Visible = True
            RB7.Visible = True
            RB1.PerformClick()
            RB1.Visible = False
            RB2.Visible = False
            RB3.Visible = False
            RB4.Visible = False
            RB5.Visible = False
            RB6.Visible = False
            RB7.Visible = False
        End If
    End Sub

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Cancelar.Click
        Close()
    End Sub

    Private Sub RB1_Click(sender As System.Object, e As System.EventArgs) Handles RB1.Click
        Me.Hide()
        Form2.Show()
    End Sub

    Private Sub Login_Click(sender As System.Object, e As System.EventArgs) Handles Login.Click, Button1.Click
        Dim tempu, tempp, a As String
        If TextBox1.Text = Nothing Or
            TextBox2.Text = Nothing Then
            MsgBox("Insira um Username e\ou Password!")
        Else
            tempp = 0
            z = 0
            a = 0
            Leitor = File.OpenText(x)
            While a = 0 And Leitor.Peek <> -1
                z = Leitor.ReadLine()
                tempu = z
                z = Leitor.ReadLine()
                tempp = z
                If TextBox1.Text = tempu Then
                    a = 1
                End If
            End While
            File.OpenText(x).Close()
            If a = 1 Then
                If TextBox2.Text = tempp Then
                    MsgBox("O Login foi Realizado com Sucesso!")
                    USERNAME = TextBox1.Text
                    Me.Hide()
                    Form3.Show()
                    Form3.Label1.Text = USERNAME
                    TextBox1.Clear()
                    TextBox2.Clear()
                Else
                    TextBox2.Text = ""
                    MsgBox("Password Errada!")
                End If
            Else
                TextBox1.Text = ""
                TextBox2.Text = ""
                MsgBox("Username Nao Encontrado!(Antes de Fazer Login Confirme que ja se Registou)")
            End If
        End If
        Leitor.Close()

    End Sub
End Class
